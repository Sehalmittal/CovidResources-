<div>
  <h2>[VOLUNTARY] Places you can Donate to</h2>
  <ul>
    <li><a href="https://hemkuntfoundation.com/donate-now/" target="_blank" rel="noopener noreferrer">Hemkunt Foundation</a> has been helping out with Oxygen Cylinders. 80G donation receipts available.</li>
    <li><a href="https://actgrants.in/donate/" target="_blank" rel="noopener noreferrer">ACT grants</a> has been helping with distribution of oxygen. Run by Indian startup ecosystem. International donations also accepted.</li>
    <li><a href="https://indiafightscorona.giveindia.org/safeperiod/" target="_blank" rel="noopener noreferrer">Give India</a> are providing sanitary napkins for women affected by the Pandemic.</li>
    <li><a href="https://www.ketto.org/fundraiser/FeedingfromfarForCorona" target="_blank" rel="noopener noreferrer">Feeding From Far</a> has been feeding the poor and unemployed who are struggling to feed themselves during the lockdown. Accepts international payments.</li>
    <li><a href="https://www.impactguru.com/fundraiser/oxygen" target="_blank" rel="noopener noreferrer">Swasth</a> along with ACT Grants is procuring oxygen concentrators and channeling them to hospitals in India.</li>
    <li><a href="https://www.feedingindia.org/donate/help-save-my-india?review_id=oxygen" target="_blank" rel="noopener noreferrer">Zomato Feeding India</a> are providing hospitals and patients with oxygen and related supplies for free. Accepts international payments.</li>
    <li><a href="https://goonj.org/support-covid-19-affected/" target="_blank" rel="noopener noreferrer">Goonj</a> is providing essentials like ration and hygiene material, with dignity, to daily wagers, migrant workers and people struggling for the basics in the villages of India. Eligible for tax deduction of 50% u/s 80G.</li>
    <li><a href="https://www.ketto.org/fundraiser/supporting-the-needy-through-COVID-19-crisis" target="_blank" rel="noopener noreferrer">Enrich Lives Foundation</a> is providing grocery kits and meals to the poor communities.</li>
    <li><a href="https://paytm.com/offer/donate-oxygen" target="_blank" rel="noopener noreferrer">Paytm Foundation</a> is raising ₹10 crore to donate Oxygen Concentrators across India. They'll match the contributions received through this initiative.</li>
    
  </ul>
</div>
