<style>
  .ad {
    background: #777777;
    color: #fafafa;
    display: block;
    width: 100%;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
    border-radius: 10px;
    text-decoration: none;
  }

  p {
    text-align: center;
    margin-top: 12px;
  }

  a:not(.ad) {
    white-space: nowrap;
  }

  .ad img {
    width: 100%;
    height: auto;
  }

  small {
    text-align: center;
    display: block;
  }
</style>

<p>An anonymous sponsor donated ₹50,000 to <a href="https://www.ketto.org/fundraiser/mission-oxygen-helping-hospitals-to-save-lives" target="_blank" rel="noopener noreferrer">Mission Oxygen</a> &amp; <a href="https://hemkuntfoundation.com/" target="_blank" rel="noopener noreferrer">Hemkunt Foundation</a> to show you this ad</p>
<a href="https://linktr.ee/hemkuntfoundation" target="_blank" class="ad">
  <img alt="Click here to donate to Hemkunt Foundation" src="img/ads/hemkunt.jpg" />
</a>
<small>This page got 1,88,000 views yesterday. To run your ad here, donate 50K INR to help patients get oxygen. <a href="https://twitter.com/umanghome/status/1386285176255180808" target="_blank" rel="noopener noreferrer">Click here to get started.</a></small>