<div>
  <h2>Other Resources</h2>
  <ul>
    <li><a href="https://covidfacts.in/" target="_blank" rel="noopener noreferrer">covidfacts.in</a></li>
  </ul>
</div>